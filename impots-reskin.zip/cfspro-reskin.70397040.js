var e,r;"function"==typeof(e=globalThis.define)&&(r=e,e=null),function(r,t,o,i,n){var s="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},a="function"==typeof s[i]&&s[i],l=a.cache||{},d="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function c(e,t){if(!l[e]){if(!r[e]){var o="function"==typeof s[i]&&s[i];if(!t&&o)return o(e,!0);if(a)return a(e,!0);if(d&&"string"==typeof e)return d(e);var n=Error("Cannot find module '"+e+"'");throw n.code="MODULE_NOT_FOUND",n}u.resolve=function(t){var o=r[e][1][t];return null!=o?o:t},u.cache={};var p=l[e]=new c.Module(e);r[e][0].call(p.exports,u,p,p.exports,this)}return l[e].exports;function u(e){var r=u.resolve(e);return!1===r?{}:c(r)}}c.isParcelRequire=!0,c.Module=function(e){this.id=e,this.bundle=c,this.exports={}},c.modules=r,c.cache=l,c.parent=a,c.register=function(e,t){r[e]=[function(e,r){r.exports=t},{}]},Object.defineProperty(c,"root",{get:function(){return s[i]}}),s[i]=c;for(var p=0;p<t.length;p++)c(t[p]);if(o){var u=c(o);"object"==typeof exports&&"undefined"!=typeof module?module.exports=u:"function"==typeof e&&e.amd?e(function(){return u}):n&&(this[n]=u)}}({"35Ivr":[function(e,r,t){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(t),o.export(t,"config",()=>i);let i={matches:["https://cfspro.impots.gouv.fr/*"],run_at:"document_idle",all_frames:!1},n="reskinEnabled",s="ir-reskin-style",a="ir-reskin-on",l="promoDismissed",d="ir-promo-banner",c="meirankri@gmail.com",p=null,u=null;function m(e){return e.replace(/\s+/g," ").trim()}function f(e,r){let t=r.toLowerCase();return e.find(e=>m(e.textContent??"").toLowerCase().startsWith(t))??null}let h={consult:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>',doc:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M9 13h6M9 17h6"/></svg>',pay:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg>',gear:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c.2.61.79 1 1.41 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',bank:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m3 9 9-6 9 6"/><path d="M4 10v9M20 10v9M8 14v3M12 14v3M16 14v3M3 21h18"/></svg>',cal:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',user:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',mail:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 5L2 7"/></svg>',at:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-3.92 7.94"/></svg>'};function x(e){return()=>{if(!e)return;let r=e.getAttribute("onclick");if(r)try{let r=e.onclick;r&&r.call(e,new MouseEvent("click"))}catch{}e.href&&!e.href.endsWith("#")?window.location.href=e.href:e.click()}}function g(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function b(e){let r=g(e.label);return`<div class="rd-tile" data-go="${r}"><span class="tic">${function(e){let r=e.toLowerCase();return r.includes("compte fiscal")||r.includes("avis")?h.consult:r.includes("comptes banc")?h.bank:r.includes("contrats")?h.pay:r.includes("g\xe9rer les services")?h.gear:r.includes("calendrier")?h.cal:r.includes("gestionnaire")?h.user:"messagerie"===r?h.mail:r.includes("adresse")?h.at:r.includes("tva")||r.includes("contributions")||r.includes("pr\xe9l\xe8v")||r.includes("cfe")||r.includes("dette")?h.pay:h.doc}(e.label)}</span><span class="tlabel">${r}</span></div>`}function v(e){return e.filter(e=>e.el).map(b).join("")}async function k(){if(document.getElementById(d))return;let e=await chrome.storage.local.get(l);if(!0===e[l])return;let r=encodeURIComponent("Automatisation IA pour mon entreprise"),t=encodeURIComponent("Bonjour Me\xefr,\n\nJ'aimerais qu'on cale un rendez-vous pour discuter d'un projet d'automatisation IA.\n\n"),o=`mailto:${c}?subject=${r}&body=${t}`,i=document.createElement("div");i.id=d,i.innerHTML=`
    <button type="button" class="ir-promo-close" aria-label="Fermer ce message">&times;</button>
    <div class="ir-promo-head">
      <div class="ir-promo-avatar">M</div>
      <div class="ir-promo-titles">
        <div class="ir-promo-eyebrow">Tu aimes cette interface ?</div>
        <div class="ir-promo-title">C'est moi qui l'ai faite. En 2 heures.</div>
      </div>
    </div>
    <p class="ir-promo-body">
      Je suis <b>Me\xefr Ankri</b>, d\xe9veloppeur sp\xe9cialis\xe9 en <b>automatisation IA</b>.
      Je transforme les processus chronophages de votre entreprise en workflows automatiques \u2014
      facturation, support, g\xe9n\xe9ration de contenu, scraping, RAG sur vos documents&hellip;
    </p>
    <p class="ir-promo-pitch">
      <b>Si vous perdez encore du temps sur des t\xe2ches r\xe9p\xe9titives</b>, on peut probablement
      les automatiser. \xc9changeons 20 minutes pour voir.
    </p>
    <a class="ir-promo-cta" href="${o}">
      <span>Discutons par email</span>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16">
        <path d="M5 12h14M13 5l7 7-7 7"/>
      </svg>
    </a>
    <div class="ir-promo-foot">${g(c)}</div>
  `;let n=i.querySelector(".ir-promo-close");n&&n.addEventListener("click",()=>{i.classList.add("ir-promo-leaving"),window.setTimeout(()=>i.remove(),200),chrome.storage.local.set({[l]:!0})}),document.body.appendChild(i)}function y(){if(document.documentElement.classList.contains(a))return;null===p&&(p=document.body.innerHTML,u=document.title);let{menu:e,deconnexion:r}=function(){let e=Array.from(document.querySelectorAll("a")),r=e.filter(e=>m(e.textContent??"").startsWith("TVA")),t={consulter:[{label:"Compte fiscal",el:f(e,"Compte fiscal")},{label:"Avis CFE",el:f(e,"Avis CFE")}],declarer:[{label:"TVA",el:r[0]??null}],payer:[{label:"TVA",el:r[1]??null},{label:"Contributions indirectes",el:f(e,"Contributions indirectes")},{label:"Pr\xe9l\xe8vement \xe0 la source",el:f(e,"Pr\xe9l\xe8vement \xe0 la source")},{label:"CFE et autres imp\xf4ts",el:f(e,"CFE et autres")},{label:"Dette fiscale",el:f(e,"Dette fiscale")}],espace:[{label:"G\xe9rer les services",el:f(e,"G\xe9rer les services")},{label:"Comptes bancaires",el:f(e,"G\xe9rer les comptes bancaires")},{label:"Contrats de pr\xe9l\xe8vement",el:f(e,"G\xe9rer les contrats")}],autres:[{label:"Calendrier fiscal",el:f(e,"Calendrier fiscal")},{label:"Gestionnaire & RDV",el:f(e,"Coordonn\xe9es du gestionnaire")}],messagerie:[{label:"Messagerie",el:f(e,"Messagerie")},{label:"Adresse \xe9lectronique de l'entreprise",el:f(e,"Adresse \xe9lectronique")}]},o=f(e,"Me d\xe9connecter");return{menu:t,deconnexion:o}}(),t=function(){let e=document.querySelector("#mon_cpte"),r=m(e?.textContent??""),t="";if(e){let r=Array.from(e.querySelectorAll("*")).map(e=>m(e.textContent??"")).filter(e=>/^M(me)?\.?\s+\S/i.test(e)&&e.length<80);t=r[0]??""}if(!t&&r){let e=r.match(/M(?:me)?\.?\s+[A-Z\u00c0-\u00dd][A-Z\u00c0-\u00dd\s\-']{2,60}/);t=e?e[0]:""}let o=r.match(/\b\d{10,}\b/),i=o?o[0]:"",n=document.querySelector("#dossier_courant3"),s=m(n?.textContent??""),a=s.match(/\b\d{3}\s?\d{3}\s?\d{3}\b/),l=a?a[0].replace(/\s+/g," "):"",d=s.replace(/SIREN/gi,"").replace(/Dossier\s+courant/gi,"").replace(/\b\d{3}\s?\d{3}\s?\d{3}\b/,"").replace(/[\u00b7\u2022|]/g,"").replace(/\s+/g," ").trim();d.length>80&&(d=d.slice(0,80)+"\u2026");let c=t||d||"??",p=c.replace(/^M(me)?\.?\s+/i,"").split(/\s+/).filter(e=>/^[A-Z\u00c0-\u00dd]/i.test(e)).slice(0,2),u=p.length>0?p.map(e=>e[0].toUpperCase()).join(""):"?";return{fullName:t,subscriberId:i,dossierName:d,siren:l,initials:u}}();if(!document.getElementById(s)){let e=document.createElement("style");e.id=s,e.textContent=M,document.head.appendChild(e)}document.documentElement.classList.add(a),document.body.innerHTML=function(e,r){let t=r.fullName?`<b>${g(r.fullName)}</b>`:"<b>Espace professionnel</b>",o=r.subscriberId?`<span>Abonn\xe9 ${g(r.subscriberId)}</span>`:"<span>impots.gouv.fr</span>",i=r.dossierName?g(r.dossierName):r.fullName?g(r.fullName):"Espace professionnel",n=r.siren?`SIREN ${g(r.siren)} \xb7 Dossier courant`:"Dossier courant";return`
    <div class="rd-top">
      <div class="brand">impots.gouv.fr<small>ESPACE PROFESSIONNEL</small></div>
      <div class="user">
        <div class="uname">${t}${o}</div>
        <button class="rd-logout" id="rd-logout" type="button">Me d\xe9connecter</button>
      </div>
    </div>
    <div class="rd-nav">
      <a data-nav="espace">Mon espace</a>
      <a data-nav="consulter">Consulter</a>
      <a data-nav="declarer">D\xe9clarer</a>
      <a data-nav="payer">Payer</a>
      <a data-nav="messagerie">Messagerie</a>
    </div>
    <div id="rd-wrap">
      <div class="rd-hero">
        <div class="avatar">${g(r.initials)}</div>
        <div><h1>${i}</h1><div class="siren">${n}</div></div>
      </div>
      <div class="rd-grid">
        <div class="rd-col">
          <div class="rd-card" id="sec-fisc">
            <h2><span class="h2ic">${h.pay}</span>Mes op\xe9rations fiscales</h2>
            <p class="sub">Consulter, d\xe9clarer et payer vos imp\xf4ts</p>
            <div class="rd-tilewrap">
              <div class="rd-seclabel" id="sec-consulter">Consulter</div>${v(e.consulter)}
              <div class="rd-seclabel" id="sec-declarer">D\xe9clarer</div>${v(e.declarer)}
              <div class="rd-seclabel" id="sec-payer">Payer</div>${v(e.payer)}
            </div>
          </div>
        </div>
        <div class="rd-col">
          <div class="rd-card" id="sec-espace">
            <h2><span class="h2ic">${h.gear}</span>Mon espace</h2>
            <div class="rd-list">${v(e.espace)}</div>
          </div>
          <div class="rd-card">
            <h2><span class="h2ic">${h.cal}</span>Autres services</h2>
            <div class="rd-list">${v(e.autres)}</div>
          </div>
          <div class="rd-card" id="sec-messagerie">
            <h2><span class="h2ic">${h.mail}</span>Messagerie</h2>
            <div class="rd-list">${v(e.messagerie)}</div>
          </div>
        </div>
      </div>
      <div class="rd-footer">Interface redessin\xe9e localement \xb7 liens d'origine pr\xe9serv\xe9s</div>
    </div>`}(e,t);let o=[...e.consulter,...e.declarer,...e.payer,...e.espace,...e.autres,...e.messagerie];document.querySelectorAll(".rd-tile").forEach(e=>{let r=e.getAttribute("data-go"),t=o.find(e=>e.label===r);t&&e.addEventListener("click",x(t.el))}),document.querySelectorAll(".rd-nav a").forEach(e=>{e.addEventListener("click",()=>{let r="sec-"+(e.getAttribute("data-nav")??""),t=document.getElementById(r);t&&t.scrollIntoView({behavior:"smooth",block:"start"})})});let i=document.getElementById("rd-logout");i&&r&&i.addEventListener("click",x(r)),k()}async function w(){let e=await chrome.storage.local.get(n),r=!1!==e[n];r&&y()}chrome.storage.onChanged.addListener((e,r)=>{if("local"!==r)return;let t=e[n];t&&(!1===t.newValue?document.documentElement.classList.contains(a)&&(null!==p&&(document.body.innerHTML=p,null!==u&&(document.title=u)),document.documentElement.classList.remove(a),document.getElementById(s)?.remove(),document.getElementById(d)?.remove()):y())}),"loading"===document.readyState?document.addEventListener("DOMContentLoaded",()=>void w(),{once:!0}):w();let M=`
html.ir-reskin-on, html.ir-reskin-on body {
  margin: 0;
  padding: 0;
  background: #eef1f6;
  color: #161616;
  font-family: 'Marianne', 'Segoe UI', system-ui, -apple-system, sans-serif;
}
html.ir-reskin-on * { box-sizing: border-box; }
html.ir-reskin-on a { text-decoration: none; color: inherit; }

html.ir-reskin-on .rd-top {
  background: #000091;
  color: #fff;
  padding: 0 32px;
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: sticky;
  top: 0;
  z-index: 20;
}
html.ir-reskin-on .rd-top .brand {
  font-weight: 800;
  font-size: 19px;
  letter-spacing: .2px;
}
html.ir-reskin-on .rd-top .brand small {
  display: block;
  font-weight: 400;
  font-size: 11.5px;
  opacity: .8;
  letter-spacing: .5px;
}
html.ir-reskin-on .rd-top .user {
  display: flex;
  align-items: center;
  gap: 18px;
  font-size: 13.5px;
}
html.ir-reskin-on .rd-top .user .uname {
  display: flex;
  flex-direction: column;
  text-align: right;
  line-height: 1.3;
}
html.ir-reskin-on .rd-top .user .uname b { font-weight: 600; }
html.ir-reskin-on .rd-top .user .uname span { opacity: .75; font-size: 11.5px; }

html.ir-reskin-on .rd-logout {
  background: rgba(255, 255, 255, .12);
  color: #fff;
  border: 1px solid rgba(255, 255, 255, .4);
  border-radius: 8px;
  padding: 9px 16px;
  font-weight: 600;
  cursor: pointer;
  font-size: 13px;
  transition: .15s;
}
html.ir-reskin-on .rd-logout:hover {
  background: #fff;
  color: #000091;
}

html.ir-reskin-on .rd-nav {
  background: #1212a3;
  height: 48px;
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 0 32px;
  position: sticky;
  top: 64px;
  z-index: 19;
}
html.ir-reskin-on .rd-nav a {
  color: #dfe1ff;
  font-size: 13px;
  font-weight: 600;
  padding: 8px 16px;
  border-radius: 8px;
  letter-spacing: .4px;
  cursor: pointer;
  transition: .15s;
}
html.ir-reskin-on .rd-nav a:hover {
  background: rgba(255, 255, 255, .14);
  color: #fff;
}

html.ir-reskin-on #rd-wrap {
  max-width: 1180px;
  margin: 0 auto;
  padding: 28px 32px 64px;
}

html.ir-reskin-on .rd-hero {
  display: flex;
  align-items: center;
  gap: 18px;
  background: linear-gradient(120deg, #000091, #2a2ad4);
  color: #fff;
  border-radius: 16px;
  padding: 24px 28px;
  margin-bottom: 22px;
  box-shadow: 0 6px 20px rgba(0, 0, 145, .18);
}
html.ir-reskin-on .rd-hero .avatar {
  width: 54px;
  height: 54px;
  border-radius: 50%;
  background: rgba(255, 255, 255, .18);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
  font-weight: 700;
  flex-shrink: 0;
  color: #fff;
}
html.ir-reskin-on .rd-hero h1 {
  margin: 0 0 3px;
  font-size: 21px;
  color: #fff;
}
html.ir-reskin-on .rd-hero .siren {
  font-size: 13.5px;
  color: #fff;
  opacity: .9;
}

html.ir-reskin-on .rd-grid {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 22px;
  align-items: start;
}
html.ir-reskin-on .rd-col {
  display: flex;
  flex-direction: column;
  gap: 22px;
}
html.ir-reskin-on .rd-card {
  background: #fff;
  border-radius: 16px;
  padding: 22px 24px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, .05);
}
html.ir-reskin-on .rd-card h2 {
  margin: 0 0 4px;
  font-size: 15px;
  color: #161616;
  display: flex;
  align-items: center;
  gap: 9px;
}
html.ir-reskin-on .rd-card h2 .h2ic {
  width: 20px;
  height: 20px;
  color: #000091;
}
html.ir-reskin-on .rd-card h2 .h2ic svg { width: 100%; height: 100%; }
html.ir-reskin-on .rd-card .sub {
  font-size: 12.5px;
  color: #888;
  margin: 0 0 14px;
}

html.ir-reskin-on .rd-tilewrap {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
}
html.ir-reskin-on .rd-tile {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 13px 14px;
  border: 1px solid #eceef4;
  border-radius: 11px;
  cursor: pointer;
  transition: .14s;
  background: #fff;
}
html.ir-reskin-on .rd-tile:hover {
  border-color: #000091;
  background: #f5f6ff;
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(0, 0, 145, .08);
}
html.ir-reskin-on .rd-tile .tic {
  width: 34px;
  height: 34px;
  border-radius: 9px;
  background: #eef0ff;
  color: #000091;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
html.ir-reskin-on .rd-tile .tic svg { width: 18px; height: 18px; }
html.ir-reskin-on .rd-tile .tlabel {
  font-size: 14px;
  font-weight: 500;
  line-height: 1.25;
}

html.ir-reskin-on .rd-seclabel {
  grid-column: 1 / -1;
  font-size: 11.5px;
  font-weight: 700;
  color: #9095a8;
  text-transform: uppercase;
  letter-spacing: .7px;
  margin: 8px 0 -2px;
}
html.ir-reskin-on .rd-seclabel:first-child { margin-top: 0; }

html.ir-reskin-on .rd-list .rd-tile {
  border: none;
  border-radius: 9px;
  padding: 11px 12px;
}
html.ir-reskin-on .rd-list .rd-tile:hover {
  background: #f5f6ff;
  transform: none;
  box-shadow: none;
}

html.ir-reskin-on .rd-footer {
  text-align: center;
  color: #a3a8b8;
  font-size: 12px;
  margin-top: 36px;
}

@media (max-width: 880px) {
  html.ir-reskin-on .rd-grid { grid-template-columns: 1fr; }
  html.ir-reskin-on .rd-tilewrap { grid-template-columns: 1fr; }
  html.ir-reskin-on .rd-nav { overflow-x: auto; }
}

/* ===== Banni\xe8re de promo d\xe9veloppeur (bas gauche) ===== */
html.ir-reskin-on #ir-promo-banner {
  position: fixed;
  bottom: 24px;
  left: 24px;
  z-index: 2147483646;
  width: 340px;
  max-width: calc(100vw - 48px);
  padding: 18px 20px 16px;
  background: #ffffff;
  color: #161616;
  border-radius: 16px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, .04), 0 12px 32px rgba(0, 0, 145, .18);
  font-family: 'Marianne', 'Segoe UI', system-ui, -apple-system, sans-serif;
  border: 1px solid rgba(0, 0, 145, .08);
  animation: ir-promo-in 320ms cubic-bezier(.16, 1, .3, 1);
  transition: opacity 200ms ease, transform 200ms ease;
}
html.ir-reskin-on #ir-promo-banner.ir-promo-leaving {
  opacity: 0;
  transform: translateY(12px);
}
@keyframes ir-promo-in {
  from { opacity: 0; transform: translateY(12px); }
  to { opacity: 1; transform: translateY(0); }
}

html.ir-reskin-on #ir-promo-banner .ir-promo-close {
  position: absolute;
  top: 8px;
  right: 10px;
  width: 26px;
  height: 26px;
  border-radius: 50%;
  background: transparent;
  border: none;
  color: #9095a8;
  font-size: 20px;
  line-height: 1;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  transition: background 120ms ease, color 120ms ease;
}
html.ir-reskin-on #ir-promo-banner .ir-promo-close:hover {
  background: #f0f1f6;
  color: #161616;
}

html.ir-reskin-on #ir-promo-banner .ir-promo-head {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
  padding-right: 24px;
}
html.ir-reskin-on #ir-promo-banner .ir-promo-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: linear-gradient(135deg, #000091, #2a2ad4);
  color: #fff;
  font-weight: 700;
  font-size: 17px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
html.ir-reskin-on #ir-promo-banner .ir-promo-titles {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}
html.ir-reskin-on #ir-promo-banner .ir-promo-eyebrow {
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: .8px;
  color: #000091;
}
html.ir-reskin-on #ir-promo-banner .ir-promo-title {
  font-size: 14.5px;
  font-weight: 700;
  color: #161616;
  line-height: 1.25;
}

html.ir-reskin-on #ir-promo-banner .ir-promo-body,
html.ir-reskin-on #ir-promo-banner .ir-promo-pitch {
  margin: 0 0 10px;
  font-size: 12.5px;
  line-height: 1.5;
  color: #3a3a3a;
}
html.ir-reskin-on #ir-promo-banner .ir-promo-body b,
html.ir-reskin-on #ir-promo-banner .ir-promo-pitch b {
  color: #161616;
  font-weight: 600;
}
html.ir-reskin-on #ir-promo-banner .ir-promo-pitch {
  background: #f5f6ff;
  padding: 10px 12px;
  border-radius: 8px;
  border-left: 3px solid #000091;
  margin-bottom: 14px;
}

html.ir-reskin-on #ir-promo-banner .ir-promo-cta {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  width: 100%;
  padding: 11px 14px;
  background: #000091;
  color: #ffffff;
  border-radius: 10px;
  font-size: 13.5px;
  font-weight: 700;
  text-decoration: none;
  letter-spacing: .2px;
  transition: background 150ms ease, transform 150ms ease, box-shadow 150ms ease;
  box-shadow: 0 4px 12px rgba(0, 0, 145, .25);
}
html.ir-reskin-on #ir-promo-banner .ir-promo-cta:hover {
  background: #1212a3;
  transform: translateY(-1px);
  box-shadow: 0 8px 18px rgba(0, 0, 145, .35);
}
html.ir-reskin-on #ir-promo-banner .ir-promo-cta:active {
  transform: translateY(0);
}

html.ir-reskin-on #ir-promo-banner .ir-promo-foot {
  text-align: center;
  font-size: 11.5px;
  color: #9095a8;
  margin-top: 8px;
  font-variant: tabular-nums;
}

@media (max-width: 600px) {
  html.ir-reskin-on #ir-promo-banner {
    left: 12px;
    right: 12px;
    bottom: 80px;
    width: auto;
  }
}
`},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],cHUbl:[function(e,r,t){t.interopDefault=function(e){return e&&e.__esModule?e:{default:e}},t.defineInteropFlag=function(e){Object.defineProperty(e,"__esModule",{value:!0})},t.exportAll=function(e,r){return Object.keys(e).forEach(function(t){"default"===t||"__esModule"===t||r.hasOwnProperty(t)||Object.defineProperty(r,t,{enumerable:!0,get:function(){return e[t]}})}),r},t.export=function(e,r,t){Object.defineProperty(e,r,{enumerable:!0,get:t})}},{}]},["35Ivr"],"35Ivr","parcelRequire086e"),globalThis.define=r;